class MemoryStorageService {
  static final Map<String, String> _users = {};

  // Register user
  static void registerUser(String email, String password) {
    _users[email] = password;
  }

  // Validate login
  static bool validateUser(String email, String password) {
    return _users.containsKey(email) && _users[email] == password;
  }

  // For testing: get all users
  static Map<String, String> getAllUsers() => _users;
}
