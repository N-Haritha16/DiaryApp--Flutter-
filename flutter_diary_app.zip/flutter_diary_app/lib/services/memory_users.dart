library memory_users;

final Map<String, String> users = {};
