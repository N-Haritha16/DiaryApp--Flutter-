class UserData {
  static final Map<String, String> _users = {}; // email -> password
  static String? loggedInUser;

  // Signup a new user
  static void signup(String email, String password) {
    _users[email] = password;
  }

  // Check if email is registered
  static bool isRegistered(String email) {
    return _users.containsKey(email);
  }

  // Login
  static bool login(String email, String password) {
    if (_users.containsKey(email) && _users[email] == password) {
      loggedInUser = email;
      return true;
    }
    return false;
  }

  // Logout
  static void logout() {
    loggedInUser = null;
  }
}
