class Note {
  String text;
  String? mood;
  List<String> tags;
  DateTime dateTime;

  Note({
    required this.text,
    this.mood,
    this.tags = const [],
    required this.dateTime,
  });

  String dateTimeFormatted() {
    // Example: Sep 13, 2025 at 08:05 AM
    return "${_monthString(dateTime.month)} ${dateTime.day}, ${dateTime.year} at ${_formatTime(dateTime)}";
  }

  String _monthString(int month) {
    const months = [
      '', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return months[month];
  }

  String _formatTime(DateTime dt) {
    int hour = dt.hour;
    final minute = dt.minute.toString().padLeft(2, '0');
    final period = hour >= 12 ? 'PM' : 'AM';
    if (hour == 0) hour = 12;
    if (hour > 12) hour -= 12;
    return "$hour:$minute $period";
  }
}
