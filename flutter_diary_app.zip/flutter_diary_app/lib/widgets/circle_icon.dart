import 'package:flutter/material.dart';

class CircleIcon extends StatelessWidget {
  final String assetPath;
  final double radius;
  final Color backgroundColor;

  const CircleIcon({
    super.key,
    required this.assetPath,
    this.radius = 50,
    this.backgroundColor = Colors.grey, // default background
  });

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: radius,
      backgroundColor: backgroundColor, // visible colored background
      child: ClipOval(
        child: Image.asset(
          assetPath,
          width: radius * 1.6, // slightly smaller than full circle
          height: radius * 1.6,
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}
