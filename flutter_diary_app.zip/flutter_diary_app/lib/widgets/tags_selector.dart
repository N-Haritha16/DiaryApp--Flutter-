import 'package:flutter/material.dart';

class TagsSelector extends StatefulWidget {
  final Function(List<String>) onTagsSelected;
  const TagsSelector({super.key, required this.onTagsSelected});

  @override
  State<TagsSelector> createState() => _TagsSelectorState();
}

class _TagsSelectorState extends State<TagsSelector> {
  final List<String> _allTags = ['Work', 'Personal', 'Health', 'Study', 'Travel'];
  List<String> _selectedTags = [];

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Wrap(
        spacing: 10,
        children: _allTags.map((tag) {
          final bool isSelected = _selectedTags.contains(tag);
          return ChoiceChip(
            label: Text(tag),
            selected: isSelected,
            selectedColor: Colors.teal,
            onSelected: (selected) {
              setState(() {
                if (selected) {
                  _selectedTags.add(tag);
                } else {
                  _selectedTags.remove(tag);
                }
                widget.onTagsSelected(_selectedTags);
              });
            },
          );
        }).toList(),
      ),
    );
  }
}
