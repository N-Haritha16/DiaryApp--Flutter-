import 'package:flutter/material.dart';

class MoodSelector extends StatefulWidget {
  final Function(String) onMoodSelected;
  const MoodSelector({super.key, required this.onMoodSelected});

  @override
  State<MoodSelector> createState() => _MoodSelectorState();
}

class _MoodSelectorState extends State<MoodSelector> {
  final List<String> _moods = ['😊', '😔', '😡', '😍', '😴'];
  String? _selectedMood;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 10,
      children: _moods.map((mood) {
        final bool isSelected = _selectedMood == mood;
        return ChoiceChip(
          label: Text(mood, style: const TextStyle(fontSize: 20)),
          selected: isSelected,
          selectedColor: Colors.teal,
          onSelected: (selected) {
            setState(() {
              _selectedMood = selected ? mood : null;
              if (_selectedMood != null) {
                widget.onMoodSelected(_selectedMood!);
              }
            });
          },
        );
      }).toList(),
    );
  }
}
