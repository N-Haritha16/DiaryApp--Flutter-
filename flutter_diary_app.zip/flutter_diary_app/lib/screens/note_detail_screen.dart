import 'package:flutter/material.dart';
import '../models/note.dart';
import '../widgets/circle_icon.dart';
import '../user_data.dart';

class NoteDetailScreen extends StatefulWidget {
  final List<Note> notes;
  final int currentIndex;

  const NoteDetailScreen({
    super.key,
    required this.notes,
    required this.currentIndex,
  });

  @override
  State<NoteDetailScreen> createState() => _NoteDetailScreenState();
}

class _NoteDetailScreenState extends State<NoteDetailScreen> {
  late int _currentIndex;
  late Note _currentNote;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.currentIndex;
    _currentNote = widget.notes[_currentIndex];
  }

  void _logout() {
    UserData.logout();
    Navigator.pushReplacementNamed(context, '/login');
  }

  void _nextNote() {
    if (_currentIndex < widget.notes.length - 1) {
      setState(() {
        _currentIndex++;
        _currentNote = widget.notes[_currentIndex];
      });
    }
  }

  void _previousNote() {
    if (_currentIndex > 0) {
      setState(() {
        _currentIndex--;
        _currentNote = widget.notes[_currentIndex];
      });
    }
  }

  void _deleteNote() {
    setState(() {
      widget.notes.removeAt(_currentIndex);
      if (_currentIndex >= widget.notes.length) {
        _currentIndex = widget.notes.length - 1;
      }
      if (widget.notes.isNotEmpty) {
        _currentNote = widget.notes[_currentIndex];
      } else {
        Navigator.pop(context); // No notes left, go back
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.notes.isEmpty) {
      return Scaffold(
        appBar: AppBar(
          title: const Text("Note Details"),
          backgroundColor: Colors.teal,
          actions: [
            IconButton(
              icon: const Icon(Icons.logout),
              onPressed: _logout,
            ),
          ],
        ),
        body: const Center(child: Text("No notes available")),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Note Details"),
        backgroundColor: Colors.teal,
        actions: [
          // Profile image on top right
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: CircleAvatar(
              backgroundImage: AssetImage('assets/profile.jpg'),
            ),
          ),
          IconButton(icon: const Icon(Icons.logout), onPressed: _logout),
        ],
      ),
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            CircleIcon(
              assetPath: "assets/note_icon.jpg",
              radius: 60,
              backgroundColor: Colors.grey,
            ),
            const SizedBox(height: 20),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _currentNote.text,
                      style: const TextStyle(fontSize: 18),
                    ),
                    const SizedBox(height: 10),
                    if (_currentNote.mood != null)
                      Text("Mood: ${_currentNote.mood}",
                          style: const TextStyle(color: Colors.teal)),
                    if (_currentNote.tags.isNotEmpty)
                      Text("Tags: ${_currentNote.tags.join(', ')}",
                          style: const TextStyle(color: Colors.teal)),
                    const SizedBox(height: 20),
                    ElevatedButton.icon(
                      onPressed: _deleteNote,
                      icon: const Icon(Icons.delete),
                      label: const Text("Delete Note"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.redAccent,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back, size: 30, color: Colors.teal),
                  onPressed: _previousNote,
                ),
                IconButton(
                  icon: const Icon(Icons.arrow_forward, size: 30, color: Colors.teal),
                  onPressed: _nextNote,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
