import 'package:flutter/material.dart';
import '../widgets/mood_selector.dart';
import '../widgets/tags_selector.dart';
import '../widgets/circle_icon.dart';
import '../models/note.dart';
import '../user_data.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  final TextEditingController _noteController = TextEditingController();
  String? selectedMood;
  List<String> selectedTags = [];
  final List<Note> savedNotes = [];

  void _saveNote() {
    if (_noteController.text.isEmpty) return;

    final newNote = Note(
      text: _noteController.text,
      mood: selectedMood,
      tags: selectedTags,
      dateTime: DateTime.now(),
    );

    setState(() {
      savedNotes.add(newNote);
      _noteController.clear();
      selectedMood = null;
      selectedTags = [];
    });
  }

  void _deleteNote(int index) {
    setState(() {
      savedNotes.removeAt(index);
    });
  }

  void _logout() {
    UserData.logout();
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Write Note'),
        backgroundColor: Colors.teal,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout,
            tooltip: 'Logout',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top note icon with background color
            const Center(
              child: CircleIcon(
                assetPath: "assets/note_icon.jpg",
                radius: 60,
                backgroundColor: Colors.grey, // visible background
              ),
            ),
            const SizedBox(height: 20),

            // Note TextField
            TextField(
              controller: _noteController,
              maxLines: 5,
              decoration: InputDecoration(
                hintText: "Write your diary note here...",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Mood Selector
            MoodSelector(onMoodSelected: (mood) {
              setState(() {
                selectedMood = mood;
              });
            }),
            const SizedBox(height: 20),

            // Tags Selector
            TagsSelector(onTagsSelected: (tags) {
              setState(() {
                selectedTags = tags;
              });
            }),
            const SizedBox(height: 20),

            // Save Button
            Center(
              child: ElevatedButton(
                onPressed: _saveNote,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  padding: const EdgeInsets.symmetric(horizontal: 60, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                child: const Text(
                  "Save Note",
                  style: TextStyle(fontSize: 18),
                ),
              ),
            ),
            const SizedBox(height: 30),

            // Saved Notes Display
            ListView.builder(
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemCount: savedNotes.length,
              itemBuilder: (context, index) {
                final note = savedNotes[index];
                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  elevation: 3,
                  child: Padding(
                    padding: const EdgeInsets.all(15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Date & Time
                        Text(
                          "${note.dateTimeFormatted()}",
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                        const SizedBox(height: 5),

                        // Note Text
                        Text(
                          note.text,
                          style: const TextStyle(fontSize: 16),
                        ),
                        const SizedBox(height: 10),

                        // Mood & Tags
                        if (note.mood != null || note.tags.isNotEmpty)
                          Wrap(
                            spacing: 10,
                            children: [
                              if (note.mood != null)
                                Chip(
                                  label: Text(note.mood!),
                                  backgroundColor: Colors.teal.shade100,
                                ),
                              ...note.tags.map((tag) => Chip(
                                    label: Text(tag),
                                    backgroundColor: Colors.teal.shade100,
                                  )),
                            ],
                          ),
                        const SizedBox(height: 10),

                        // Delete Button
                        Align(
                          alignment: Alignment.centerRight,
                          child: IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _deleteNote(index),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
