import 'package:flutter_test/flutter_test.dart';
import 'package:diary_app/main.dart';

void main() {
  testWidgets('App starts without errors', (WidgetTester tester) async {
    await tester.pumpWidget(DiaryApp());
    expect(find.text('Login'), findsOneWidget);
  });
}
