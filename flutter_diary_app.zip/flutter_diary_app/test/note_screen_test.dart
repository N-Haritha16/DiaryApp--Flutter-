import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:diary_app/screens/note_screen.dart';
import 'package:diary_app/widgets/mood_selector.dart';
import 'package:diary_app/widgets/tags_selector.dart';

void main() {
  testWidgets('NoteScreen contains MoodSelector and TagsSelector',
      (WidgetTester tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: NotesScreen(),
      ),
    );

    // Verify MoodSelector exists
    expect(find.byType(MoodSelector), findsOneWidget);

    // Verify TagsSelector exists
    expect(find.byType(TagsSelector), findsOneWidget);

    // Verify note textfield exists
    expect(find.byType(TextField), findsOneWidget);
  });
}
